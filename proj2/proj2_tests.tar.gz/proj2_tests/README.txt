The *.out files were generated using the following commands.

$ cat ./src<i> | ./parser > ./src<i>.out

The output of your parser should match these outputs save for minor
differences.
